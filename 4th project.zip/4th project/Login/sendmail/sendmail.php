<?php 
    $msg = "First line of text \n Second line of text ";


    //send mail
    if(mail("prathamshrestha100@gmail.com","My subject",$msg)){
        echo"Email successfully sent ...";
    }
    else{
        echo "Email sending failed...";
    }


?>